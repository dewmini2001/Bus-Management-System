
public class Driver extends Member{



    public Driver(String Username, String ID) {
       super(Username,ID);
    }

    public String getUsername() {
        return name;
    }

    public String getDriverID() {
        return ID;
    }
}



