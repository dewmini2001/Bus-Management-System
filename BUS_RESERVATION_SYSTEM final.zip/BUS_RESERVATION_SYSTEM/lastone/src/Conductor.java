public class Conductor extends Member {




        public Conductor(String Username, String ID) {
         super(Username,ID);
        }

        public String getUsername() {
            return name;
        }

    public String getConductorID() {
        return ID;
    }
    }

