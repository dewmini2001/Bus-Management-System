
import java.util.ArrayList;

interface abstraction {
      void  addingDrivers(ArrayList<Driver> Drivers);
      void addingconductors(ArrayList<Conductor> conductors);

    }

